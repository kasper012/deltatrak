<?php

return [
    'fullname.required' => 'Ad və soyadı qeyd etməyiniz məcburidir',
    'subject.required' => 'Məktubun mövzusunu qeyd etmək məcburidir',
    'email.required' => 'Email ünvanınızı qeyd etmək məcburidir',
    'email.email' => 'Zəhmət olmasa düzgün email ünvanını qeyd edəsiniz',
    'phone.required' => 'Əlaqə nömrənizi qeyd etmək məcburidir',
    'msg.required' => 'Məktubun məzmununu qeyd etmək məcburidir',
    'msg.sent' => 'Məktubunuz göndərildi'
];
